module.exports = {
  images: {
    domains: [],
  },
}
