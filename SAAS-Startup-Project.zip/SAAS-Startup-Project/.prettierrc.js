module.exports = {
  semi: false,
  trailingComma: 'es5',
  arrowParens: 'always',
  singleQuote: true,
  proseWrap: 'never',
}
